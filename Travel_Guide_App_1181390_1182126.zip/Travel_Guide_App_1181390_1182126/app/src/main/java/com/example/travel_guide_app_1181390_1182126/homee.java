package com.example.travel_guide_app_1181390_1182126;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class homee extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homee);
    }
}